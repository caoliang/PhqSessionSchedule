package com.phqtime.phqtimetable;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WorkPeriod")
public class WorkPeriod implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long id;
	private WorkDay day;
	private WorkTimeslot timeslot;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public WorkDay getDay() {
		return day;
	}

	public void setDay(WorkDay day) {
		this.day = day;
	}

	public WorkTimeslot getTimeslot() {
		return timeslot;
	}

	public void setTimeslot(WorkTimeslot timeslot) {
		this.timeslot = timeslot;
	}

	@Override
	public String toString() {
		return day + "-" + timeslot;
	}

	public WorkPeriod(long id, WorkDay day, WorkTimeslot timeslot) {
		this.id = id;
		this.day = day;
		this.timeslot = timeslot;
	}
	
	public String getDesc() {
		StringBuffer buf = new StringBuffer();
		buf.append("id: ").append(id).append(", ");
		buf.append("day: ").append(day.getDesc()).append(", ");
		buf.append("time: ").append(timeslot.getDesc());
		
		return buf.toString();
	}
}