/*
 * Copyright 2012 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.phqtime.phqtimetable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;
import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;
import org.optaplanner.core.api.solver.event.BestSolutionChangedEvent;
import org.optaplanner.core.api.solver.event.SolverEventListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhqSessionScheduleApp {

    private static Logger log = LoggerFactory.getLogger(PhqSessionScheduleApp.class);
	
    public static void main(String[] args) {
        // Build the Solver
        SolverFactory<PhqSessionScheduleSolution> solverFactory = SolverFactory.createFromXmlResource(
                "com/phqtime/phqtimetable/TimeSolver.solver.xml");
        Solver<PhqSessionScheduleSolution> solver = solverFactory.buildSolver();
        solver.addEventListener(new SolverEventListener<PhqSessionScheduleSolution>() {
			@Override
			public void bestSolutionChanged(BestSolutionChangedEvent<PhqSessionScheduleSolution> event) {
				log.info("Best solution score: {}", event.getNewBestScore());
			}
		});
        

        // Create sample test data
        PhqSessionScheduleSolution unsolvedSolution = createUnsolvedSolution();

        // Solve the problem
        PhqSessionScheduleSolution solvedSolution = solver.solve(unsolvedSolution);
        
        // Display the result
        log.info("\nSolved Solution:\n {}", displayResult(solvedSolution));
    }

    public static String displayResult(PhqSessionScheduleSolution solution) {
        StringBuilder buf = new StringBuilder();
        buf.append("Total score: ").append(solution.getScore().toString()).append("\n");
        
        List<PhqProcess> processList = solution.getPhqProcessList();
        long processIndex = 0;
        for (PhqProcess process : processList) {
            buf.append(processIndex).append(" -> ").append(process.getDesc()).append("\n");
            processIndex++;
        }
        return buf.toString();
    }

    public static List<PhqPatient> readPatientDataFromCSV(String filePath, List<WorkDay> workDayList) {
    	List<PhqPatient> patientList = new ArrayList<PhqPatient>();
    	File csvFile = new File(filePath);
    	if (!csvFile.exists() || !csvFile.isFile() || !csvFile.canRead()) {
    		throw new RuntimeException("Cannot read patient file: (" + filePath + ")");
    	}
    	
    	long patientId = 0;
    	try {
        	BufferedReader csvFileReader = new BufferedReader(new FileReader(csvFile));
        	String line = null;
        	while ((line = csvFileReader.readLine()) != null) {
        		if (line.trim().equals("")) {
        			continue;
        		}
        		String[] patientData = line.split(",");
        		if (patientData.length != 8) {
        			log.error("Cannot read patient date at line ({})", line);
        			continue;
        		}
        		
        		//Skip title line
        		if (patientData[0].trim().equalsIgnoreCase("Sno")) {
        			continue;
        		}
        		
        		// Sno,PHQ-9 Score,Session hours needed,Practitioner Role,Practitioner Language,
        		// Practitioner Gender,Insitution Location,Session Day
        		String patientNum = patientData[0].trim();
        		int phqScore = Integer.parseInt(patientData[1].trim());
        		//String practionerRole = patientData[3].trim();
        		String preferLanguage = patientData[4].trim();
        		String preferGender = patientData[5].trim();
        		String preferLocation = patientData[6].trim();
        		String preferDayDesc = patientData[7].trim().substring(0, 2);
        		WorkDay preferWorkDay = WorkDay.getWorkDay(preferDayDesc, workDayList);
        		
        		PhqPatient patient = new PhqPatient(patientId, patientNum, phqScore, preferGender, 
        				preferLanguage, preferLocation, preferWorkDay);
        		patientList.add(patient);
        	}
        	csvFileReader.close();
			
		} catch (Exception exp) {
			log.error("Read patient data file (" + filePath + ") error", exp);
			throw new RuntimeException("Cannot read patient file: (" + filePath + ")");
		}
    	
    	return patientList;
    }
    
    public static List<PhqPractioner> readPractionerDataFromCSV(String filePath, List<WorkDay> workDayList, 
    		List<UnavailableDay> notFreeDayList, List<PhqInstitution> institutionList) 
    {
    	Map<String, PhqInstitution> institutionMap = new HashMap<String, PhqInstitution>();
    	List<PhqPractioner> practionerList = new ArrayList<PhqPractioner>();
    	File csvFile = new File(filePath);
    	if (!csvFile.exists() || !csvFile.isFile() || !csvFile.canRead()) {
    		throw new RuntimeException("Cannot read Practioner file: (" + filePath + ")");
    	}
    	
    	long practionerId = 0;
    	try {
        	BufferedReader csvFileReader = new BufferedReader(new FileReader(csvFile));
        	String line = null;
        	while ((line = csvFileReader.readLine()) != null) {
        		if (line.trim().equals("")) {
        			continue;
        		}
        		String[] practionerData = line.split(",");
        		if (practionerData.length != 19) {
        			log.error("Cannot read practioner date at line (length: {}), ({})", practionerData.length, line);
        			continue;
        		}
        		
        		//Skip title line
        		if (practionerData[0].trim().equalsIgnoreCase("Sno")) {
        			continue;
        		}
        		
        		// Sno,Practitioner Name,Practitioner Role,"Practitioner  Unavailability Mon","Practitioner Unavailability Tue",
        		// "Practitioner Unavailability Wed","Practitioner Unavailability Thur","Practitioner Unavailability Fri","Practitioner Unavailability Sat","Practitioner Unavailability Sun",
        		// "Practitioner  Language","Practitioner  Gender","Practitioner  Cost",Insitution Name,Insitution Type,
        		// Insitution Location,Location of insitutions,Day_insitutions,Hour_insitutions

        		String practionerName = practionerData[1].trim();
        		String practionerRole = practionerData[2].trim();
        		String language = practionerData[10].trim();
        		String gender = practionerData[11].trim();
        		String location = practionerData[15].trim();
        		int costPerHour = Integer.parseInt(practionerData[12].trim());
        		
        		PhqPractioner practioner = new PhqPractioner(practionerId, practionerName, gender, practionerRole, 
        				location, language, costPerHour);
        		practionerList.add(practioner);
        		
        		for (int i = 0; i < 7; ++i) {
        			String notFreeTime = practionerData[3 + i].trim();
        			if (notFreeTime.contentEquals("0900-2100")) {
        				UnavailableDay notFreeDay = new UnavailableDay(notFreeDayList.size(), practioner, workDayList.get(i));
        				notFreeDayList.add(notFreeDay);
        			}
        		}
        		
        		String institutionName = practionerData[13].trim();
        		String institutionType = practionerData[14].trim();
        		String institutionLocation = practionerData[15].trim();
        		String institutionAddr = practionerData[16].trim();
        		PhqInstitution institution = institutionMap.get(institutionName.toLowerCase());
        		
        		if (institution == null) {
        			institution = new PhqInstitution(institutionList.size(), institutionName, 
        					institutionLocation, institutionType, institutionAddr);
        			institutionList.add(institution);
        			institutionMap.put(institutionName.toLowerCase(), institution);
        		}
        		
        		practioner.setInstitution(institution);
        	}
        	csvFileReader.close();
			
		} catch (Exception exp) {
			log.error("Read practioner data file (" + filePath + ") error", exp);
			throw new RuntimeException("Cannot read practioner file: (" + filePath + ")");
		}
    	
    	return practionerList;
    }
    
    public static PhqSessionScheduleSolution createUnsolvedSolution() {
    	long solutionId = 0;

    	List<WorkDay> dayList = new ArrayList<WorkDay>(WorkDay.getWorkDaySize());
    	for (int i = 0; i < WorkDay.getWorkDaySize(); ++i) {
    		WorkDay day = new WorkDay(i, i);
    		dayList.add(day);
    	}
    	
    	List<WorkTimeslot> timeslotList = new ArrayList<WorkTimeslot>(WorkTimeslot.getTimeslotSize());
    	for (int i = 0; i < WorkTimeslot.getTimeslotSize(); ++i) {
    		WorkTimeslot timeslot = new WorkTimeslot(i, i);
     		timeslotList.add(timeslot);
    	}
    	
    	List<PhqPatient> patientList = readPatientDataFromCSV("testdata\\patientData.csv", dayList);
    	for (PhqPatient patient : patientList) {
    		log.info("Patient: {}", patient.getDesc());
    	}

    	List<PhqInstitution> institutionList = new LinkedList<PhqInstitution>();
    	List<UnavailableDay> notFreeDayList = new LinkedList<UnavailableDay>();
    	List<PhqPractioner> practionerList = readPractionerDataFromCSV("testdata\\practionerData.csv", 
    			dayList, notFreeDayList, institutionList);
//    	PhqPractioner selPractioner = practionerList.get(0);
//    	practionerList.clear();
//    	practionerList.add(selPractioner);
    	practionerList.add(PhqPractioner.NIL_PRACTIONER);
    	
    	for (PhqPractioner practioner : practionerList) {
    		log.info("practioner: {}", (practioner == null) ? "NULL" : practioner.getDesc());
    	}
    	
    	List<WorkPeriod> periodList = new ArrayList<WorkPeriod>(dayList.size() * timeslotList.size());
    	int periodId = 0;
    	for (int i = 0; i < dayList.size(); ++i) {
    		WorkDay day = dayList.get(i);
    		List<WorkPeriod> dayPeriodList = new ArrayList<WorkPeriod>(timeslotList.size());
    		day.setPeriodList(dayPeriodList);
    		
    		for (int j = 0; j < timeslotList.size(); ++j) {
    			WorkTimeslot timeslot = timeslotList.get(j);
    			WorkPeriod currentPeriod = new WorkPeriod(periodId, day, timeslot);
    			dayPeriodList.add(currentPeriod);
    			periodList.add(currentPeriod);
    			periodId++;
    		}
    	}
    	
    	List<PhqProcess> processList = new ArrayList<PhqProcess>(patientList.size());
    	long processId = 0;
    	for (PhqPatient patient : patientList) {
    		PhqProcess process = new PhqProcess(processId, null, patient, periodList.get(0));
        	processList.add(process);
        	processId++;
    	}
    	
    	HardSoftScore score = HardSoftScore.ZERO;
    	PhqSessionScheduleSolution solution = new PhqSessionScheduleSolution(solutionId, practionerList, institutionList,
    			patientList, periodList, processList, notFreeDayList, score);
    	
    	return solution;
    }
}
