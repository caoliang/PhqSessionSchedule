package phq.dto;

import com.phqtime.phqtimetable.PhqProcess;

public class MatchResultDto {

    private long processId;
    private String patientName;
    private String patientScore;
    private String practitionerName;
    private String practitionerRole;
    private String practitionerGender;
    private String practitionerLanguage;
    private String session;
    private String overallLocation;
    private String detailLocation;

    public MatchResultDto(PhqProcess phqProcess) {

        this.processId = phqProcess.getId();
        this.patientName = phqProcess.getPatientSelected().getName();
        this.patientScore = String.valueOf( phqProcess.getPatientSelected().getPhqScore() );

        this.practitionerName = phqProcess.getSelectedPractioner().getName();
        this.practitionerRole = phqProcess.getSelectedPractioner().getRoleDesc();
        this.practitionerGender = phqProcess.getSelectedPractioner().getGenderDesc();
        this.practitionerLanguage = phqProcess.getSelectedPractioner().getLanguageDesc();

        this.session = phqProcess.getSelectedPeriod().getTimeslot().getDesc();
        this.overallLocation = phqProcess.getSelectedPractioner().getLocationDesc();
        this.detailLocation = phqProcess.getSelectedPractioner().getInstitution().getAddress();
    }

    public long getProcessId() {
        return processId;
    }

    public void setProcessId(long processId) {
        this.processId = processId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientScore() {
        return patientScore;
    }

    public void setPatientScore(String patientScore) {
        this.patientScore = patientScore;
    }

    public String getPractitionerName() {
        return practitionerName;
    }

    public void setPractitionerName(String practitionerName) {
        this.practitionerName = practitionerName;
    }

    public String getPractitionerRole() {
        return practitionerRole;
    }

    public void setPractitionerRole(String practitionerRole) {
        this.practitionerRole = practitionerRole;
    }

    public String getPractitionerGender() {
        return practitionerGender;
    }

    public void setPractitionerGender(String practitionerGender) {
        this.practitionerGender = practitionerGender;
    }

    public String getPractitionerLanguage() {
        return practitionerLanguage;
    }

    public void setPractitionerLanguage(String practitionerLanguage) {
        this.practitionerLanguage = practitionerLanguage;
    }

    public String getSession() {
        return session;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public String getOverallLocation() {
        return overallLocation;
    }

    public void setOverallLocation(String overallLocation) {
        this.overallLocation = overallLocation;
    }

    public String getDetailLocation() {
        return detailLocation;
    }

    public void setDetailLocation(String detailLocation) {
        this.detailLocation = detailLocation;
    }
}
