package phq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import phq.dto.PatientDto;
import phq.dto.PractitionerDto;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Service
public class PatientService {

    @Autowired
    private DBConnectionService dbConnectionService;

    public List<PatientDto> getAllPatients() throws Exception{

        List<PatientDto> list = new ArrayList<>();
        Connection conn = dbConnectionService.getConn();
        Statement stmt = conn.createStatement();

        ResultSet rs = stmt.executeQuery("select * from phq_patient_preference");
        while( rs.next() ) {
            int sno = rs.getInt(1);
            int phq9Score = rs.getInt(2);
            String practitionerRole = rs.getString(3);
            String practitionerLanguage = rs.getString(4);
            String practitionerGender = rs.getString(5);
            String institutionLocation = rs.getString(6);
            String sessionDay = rs.getString(7);

            PatientDto dto = new PatientDto(sno, phq9Score, practitionerRole, practitionerLanguage, practitionerGender, institutionLocation, sessionDay);
            list.add(dto);
        }
        return list;
    }

    public List<PractitionerDto> getAllPractioners() throws Exception{

        List<PractitionerDto> list = new ArrayList<>();
        Connection conn = dbConnectionService.getConn();
        Statement stmt = conn.createStatement();

        ResultSet rs = stmt.executeQuery("select * from phq_practioner_availability");
        while( rs.next() ) {
            int sno = rs.getInt(1);
            String name = rs.getString(2);
            String role = rs.getString(3);
            String language = rs.getString(4);
            String gender = rs.getString(5);
            String cost = rs.getString(6);

            String monday = rs.getString(7);
            String tuesday = rs.getString(8);
            String wednesday = rs.getString(9);
            String thursday = rs.getString(10);
            String friday = rs.getString(11);
            String saturday = rs.getString(12);
            String sunday = rs.getString(13);

            String institutionName = rs.getString(14);
            String institutionType = rs.getString(15);
            String institutionOverallLocation = rs.getString(16);
            String institutionDetailLocation = rs.getString(17);

            PractitionerDto dto = new PractitionerDto(sno, name, role, language, gender, cost,
                    monday, tuesday, wednesday, thursday, friday, saturday, sunday,
                    institutionName, institutionType, institutionOverallLocation, institutionDetailLocation);

            list.add(dto);
        }
        return list;
    }
}

