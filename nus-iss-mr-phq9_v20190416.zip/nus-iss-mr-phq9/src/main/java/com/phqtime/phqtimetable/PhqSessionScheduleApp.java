/*
 * Copyright 2012 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.phqtime.phqtimetable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.kie.soup.commons.xstream.XStreamUtils;
import org.optaplanner.benchmark.api.PlannerBenchmark;
import org.optaplanner.benchmark.api.PlannerBenchmarkFactory;
import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;
import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;
import org.optaplanner.core.api.solver.event.BestSolutionChangedEvent;
import org.optaplanner.core.api.solver.event.SolverEventListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thoughtworks.xstream.XStream;
import phq.dto.PatientDto;
import phq.dto.PractitionerDto;

public class PhqSessionScheduleApp {

    private static Logger log = LoggerFactory.getLogger(PhqSessionScheduleApp.class);
	
    private static boolean READ_UNSOLVED_SOLUTION_FROM_CSV = true;
    private static boolean CREATE_UNSOLVED_SOLUTION_XML = false;
    private static boolean READ_UNSOLVED_SOLUTION_FROM_XML = false;
    private static boolean BENCHMARK_TEST = false;
    private static boolean PLANNING_ON_EXISTING_SOLUTION = false;
    private static boolean TEMPLATE_TEST = false;

	static Solver<PhqSessionScheduleSolution> solver;

    public static void main(String[] args) {
    	if (args.length >= 1) {
    		BENCHMARK_TEST = args[0].equalsIgnoreCase("benchmark");
    		TEMPLATE_TEST = args[0].equalsIgnoreCase("template");
    		READ_UNSOLVED_SOLUTION_FROM_XML = args[0].equalsIgnoreCase("readDataFromXml");
    		CREATE_UNSOLVED_SOLUTION_XML = args[0].equalsIgnoreCase("createXmlData");
    		PLANNING_ON_EXISTING_SOLUTION = args[0].equalsIgnoreCase("planMore");
    	}
    	
    	String xmlSolutionOutPath = "benchmark/data/resolved/PhqTimeTableSolutionData.xml";
    	String xmlPlanMoreSolutionOutPath = "benchmark/data/resolved/PhqTimeTablePlanMoreSolutionData.xml";
    	
    	PhqSessionScheduleSolution planMoreUnsolvedSolution = null;
    	// Plan more with added patient data
    	if (PLANNING_ON_EXISTING_SOLUTION) {
    		log.info("Read existing solved solution from XML data files");
            try {
                XStream readStream = XStreamUtils.createTrustingXStream();
                planMoreUnsolvedSolution = (PhqSessionScheduleSolution)readStream.fromXML(new FileReader(xmlSolutionOutPath));
    		} catch (Exception exp) {
    			log.error(String.format("Cannot read existing solved solution from xml (1$)", xmlSolutionOutPath), exp);
    			return;
    		}
    		
            List<WorkDay> dayList = WorkDay.getAllWorkDayList();
            List<WorkPeriod> periodList = planMoreUnsolvedSolution.getPeriodList();
            // Add new patient data
            List<PhqPatient> addedPatientList = readPatientDataFromCSV("testdata\\patientMoreData_v1.csv", dayList);
            List<PhqPatient> solutionPatientList = planMoreUnsolvedSolution.getPatientList();
            solutionPatientList.addAll(addedPatientList);
            
            List<WorkTimeslot> timeslotList = WorkTimeslot.getAllTimeslotList();
        	List<WorkPeriod> notFreePeriodList = planMoreUnsolvedSolution.getUnavailablePeriodList();
        	Map<String, WorkPeriod> periodMap = WorkPeriod.constructPeriodMap();
        	List<PhqInstitution> institutionList = planMoreUnsolvedSolution.getInstituionList();
        	
            List<PhqPractioner> addedPractionerList = readPractionerDataFromCSV("testdata\\practionerMoreData_v1.csv", 
        			dayList, timeslotList, periodMap, notFreePeriodList, institutionList);
            List<PhqPractioner> solutionPractionerList = planMoreUnsolvedSolution.getPractionerList();
            solutionPractionerList.addAll(addedPractionerList);
            
            List<PhqProcess> solutionProcessList = planMoreUnsolvedSolution.getPhqProcessList();
        	long processId = solutionProcessList.get(solutionProcessList.size() - 1).getId() + 1;
        	for (PhqPatient patient : addedPatientList) {
        		PhqProcess process = new PhqProcess(processId, null, patient, periodList.get(0));
            	solutionProcessList.add(process);
            	processId++;
        	}
            
            // Build the Solver
        	SolverFactory<PhqSessionScheduleSolution> solverFactory = SolverFactory.createFromXmlResource(
    				"com/phqtime/phqtimetable/TimeSolver.solver.xml");
        	Solver<PhqSessionScheduleSolution> solver = solverFactory.buildSolver();
            solver.addEventListener(new SolverEventListener<PhqSessionScheduleSolution>() {
    			@Override
    			public void bestSolutionChanged(BestSolutionChangedEvent<PhqSessionScheduleSolution> event) {
    				log.info("Best solution score: {}", event.getNewBestScore());
    			}
    		});
            
            // Solve the problem
            long startTime = System.currentTimeMillis();
            PhqSessionScheduleSolution planMoreSolvedSolution = solver.solve(planMoreUnsolvedSolution);
            planMoreSolvedSolution.confirmSolution();
            long endTime = System.currentTimeMillis();
            
            // Display the result
            log.info("\nPlan More Solved Solution in {} with score {}:\n", 
            		getTimePeriodDesc(endTime - startTime), 
            		planMoreSolvedSolution.getScore());
            
            //log.info(displayResult(solvedSolution));
            //Save solved solution to xml
            XStream writeStream = XStreamUtils.createTrustingXStream();
            String planMoreSolvedSolutionXml = writeStream.toXML(planMoreSolvedSolution);
            log.debug("planMoreSolvedSolutionXml: (Length: {})", planMoreSolvedSolutionXml.length());
            try {
            	writeStream.toXML(planMoreSolvedSolution, new FileWriter(xmlPlanMoreSolutionOutPath));
    	        log.info("Completed to write planMoreSolvedSolutionXml: (Length: {})", planMoreSolvedSolutionXml.length());
    		} catch (Exception exp) {
    	        log.error(String.format("Write plan more solved solution xml (1$) error", xmlPlanMoreSolutionOutPath), exp);
    		}
            
    		return;
    	}
    	
    	// Either choose to read from CSV files for unsolved solution, or from xml files 
    	READ_UNSOLVED_SOLUTION_FROM_CSV = !READ_UNSOLVED_SOLUTION_FROM_XML;
    	
    	if (BENCHMARK_TEST) {
    		PlannerBenchmarkFactory plannerBenchmarkFactory = PlannerBenchmarkFactory.createFromXmlResource(
    				"com/phqtime/phqtimetable/TimeSolver_Benchmark.xml");
    		PlannerBenchmark plannerBenchmark = plannerBenchmarkFactory.buildPlannerBenchmark();
            
    		log.info("Start PhqSessionSchedule benchmark ...");
            long startTime = System.currentTimeMillis();
    		plannerBenchmark.benchmark();
    		long endTime = System.currentTimeMillis();
    		log.info("Completed PhqSessionSchedule benchmark in {}", getTimePeriodDesc(endTime - startTime));
    		
    		return;
    	}
    	
    	if (TEMPLATE_TEST) {
    		PlannerBenchmarkFactory plannerBenchmarkFactory = PlannerBenchmarkFactory.createFromFreemarkerXmlResource(
    				"com/phqtime/phqtimetable/TimeSolver_Template.xml.ftl");
    		PlannerBenchmark plannerBenchmark = plannerBenchmarkFactory.buildPlannerBenchmark();
            
    		log.info("Start PhqSessionSchedule template ...");
            long startTime = System.currentTimeMillis();
    		plannerBenchmark.benchmark();
    		long endTime = System.currentTimeMillis();
    		log.info("Completed PhqSessionSchedule template in {}", getTimePeriodDesc(endTime - startTime));
    		
    		return;
    	}
    	
        // Build the Solver
    	SolverFactory<PhqSessionScheduleSolution> solverFactory = SolverFactory.createFromXmlResource(
				"com/phqtime/phqtimetable/TimeSolver.solver.xml");
    	Solver<PhqSessionScheduleSolution> solver = solverFactory.buildSolver();
        solver.addEventListener(new SolverEventListener<PhqSessionScheduleSolution>() {
			@Override
			public void bestSolutionChanged(BestSolutionChangedEvent<PhqSessionScheduleSolution> event) {
				log.info("Best solution score: {}", event.getNewBestScore());
			}
		});
        
        // Create sample test data
        PhqSessionScheduleSolution unsolvedSolution = null;
        String xmlOutPath = "benchmark/data/unresolved/PhqTimeTableBaseData.xml";
        // Save unresolved solution xml file
        if (CREATE_UNSOLVED_SOLUTION_XML) {
        	unsolvedSolution = createUnsolvedSolution();
	        XStream writeStream = XStreamUtils.createTrustingXStream();
	        String unsolvedSolutionXml = writeStream.toXML(unsolvedSolution);
	        log.debug("unsolvedSolutionXml: (Length: {})", unsolvedSolutionXml.length());
	        try {
	        	writeStream.toXML(unsolvedSolution, new FileWriter(xmlOutPath));
		        log.info("Completed to write unsolvedSolutionXml: (Length: {})", unsolvedSolutionXml.length());
			} catch (Exception exp) {
		        log.error(String.format("Write unsolved solution xml (1$) error", xmlOutPath), exp);
			}
	        
	        return;
        }
        
        //Read unsolved solution from xml file
        if (READ_UNSOLVED_SOLUTION_FROM_XML) {
        	log.info("Read unsolved solution from XML data files");
            try {
                XStream readStream = XStreamUtils.createTrustingXStream();
                unsolvedSolution = (PhqSessionScheduleSolution)readStream.fromXML(new FileReader(xmlOutPath));
    		} catch (Exception exp) {
    			log.error(String.format("Cannot read unsolved solution from xml (1$)", xmlOutPath), exp);
    			return;
    		}
        }
        
        // Create unsolved solution from CSV data files
        if (READ_UNSOLVED_SOLUTION_FROM_CSV) {
        	log.info("Read unsolved solution from CSV files");
        	unsolvedSolution = createUnsolvedSolution();
        }
        
        // Solve the problem
        long startTime = System.currentTimeMillis();
        PhqSessionScheduleSolution solvedSolution = solver.solve(unsolvedSolution);
        solvedSolution.confirmSolution();
        long endTime = System.currentTimeMillis();
        
        // Display the result
        log.info("\nSolved Solution in {} with score {}:\n", 
        		getTimePeriodDesc(endTime - startTime), 
        		solvedSolution.getScore());
        
        log.info(displayResult(solvedSolution));
        
        //Save solved solution to xml
        XStream writeStream = XStreamUtils.createTrustingXStream();
        String solvedSolutionXml = writeStream.toXML(solvedSolution);
        log.debug("solvedSolutionXml: (Length: {})", solvedSolutionXml.length());
        try {
        	writeStream.toXML(solvedSolution, new FileWriter(xmlSolutionOutPath));
	        log.info("Completed to write solvedSolutionXml: (Length: {})", solvedSolutionXml.length());
		} catch (Exception exp) {
	        log.error(String.format("Write solved solution xml (1$) error", xmlSolutionOutPath), exp);
		}
    }

	public static Solver<PhqSessionScheduleSolution> getSolver() {
		if(solver != null ) {
			return solver;
		}
		SolverFactory<PhqSessionScheduleSolution> solverFactory = SolverFactory.createFromXmlResource(
				"com/phqtime/phqtimetable/TimeSolver.solver.xml");

		solver = solverFactory.buildSolver();
		solver.addEventListener(new SolverEventListener<PhqSessionScheduleSolution>() {
			@Override
			public void bestSolutionChanged(BestSolutionChangedEvent<PhqSessionScheduleSolution> event) {
				log.info("Best solution score: {}", event.getNewBestScore());
			}
		});

		return solver;
	}

    public static String getTimePeriodDesc(long intervalMillis) {
    	StringBuffer buf = new StringBuffer();
    	buf.append((int)(intervalMillis / 1000 / 3600)).append(":");
    	buf.append((int)(intervalMillis / 1000 % 3600 / 60)).append(":");
    	buf.append((int)(intervalMillis / 1000 % 60)).append(".");
    	buf.append((int)(intervalMillis / 1000 % 60)).append(".");
    	
    	return buf.toString();
    }
    
    public static String displayResult(PhqSessionScheduleSolution solution) {
        StringBuilder buf = new StringBuilder();
        buf.append("Total score: ").append(solution.getScore().toString()).append("\n");
        
        List<PhqProcess> processList = solution.getPhqProcessList();
        long processIndex = 0;
        for (PhqProcess process : processList) {
            buf.append(processIndex).append(" -> ").append(process.getDesc()).append("\n");
            processIndex++;
        }
        return buf.toString();
    }

    public static List<PhqPatient> readPatientDataFromCSV(String filePath, List<WorkDay> workDayList) {
    	List<PhqPatient> patientList = new ArrayList<PhqPatient>();
    	File csvFile = new File(filePath);
    	if (!csvFile.exists() || !csvFile.isFile() || !csvFile.canRead()) {
    		throw new RuntimeException("Cannot read patient file: (" + filePath + ")");
    	}
    	
    	long patientId = 0;
    	try {
        	BufferedReader csvFileReader = new BufferedReader(new FileReader(csvFile));
        	String line = null;
        	while ((line = csvFileReader.readLine()) != null) {
        		if (line.trim().equals("")) {
        			continue;
        		}
        		String[] patientData = line.split(",");
        		if (patientData.length != 7) {
        			log.error("Cannot read patient date at line ({})", line);
        			continue;
        		}
        		
        		//Skip title line
        		if (patientData[0].trim().equalsIgnoreCase("Sno")) {
        			continue;
        		}
        		
        		// Sno,PHQ-9 Score,Session hours needed,Practitioner Role,Practitioner Language,
        		// Practitioner Gender,Insitution Location,Session Day
        		String patientNum = patientData[0].trim();
        		int phqScore = Integer.parseInt(patientData[1].trim());
        		//String practionerRole = patientData[2].trim();
        		String preferLanguage = patientData[3].trim();
        		String preferGender = patientData[4].trim();
        		String preferLocation = patientData[5].trim();
        		String preferDayDesc = patientData[6].trim().substring(0, 2);
        		WorkDay preferWorkDay = WorkDay.getWorkDay(preferDayDesc, workDayList);
        		
        		PhqPatient patient = new PhqPatient(patientId, patientNum, phqScore, preferGender, 
        				preferLanguage, preferLocation, preferWorkDay);
        		patientList.add(patient);
        	}
        	csvFileReader.close();
			
		} catch (Exception exp) {
			log.error("Read patient data file (" + filePath + ") error", exp);
			throw new RuntimeException("Cannot read patient file: (" + filePath + ")");
		}
    	
    	return patientList;
    }
    
    public static List<PhqPractioner> readPractionerDataFromCSV(String filePath, List<WorkDay> dayList, 
    		List<WorkTimeslot> timeslotList, Map<String, WorkPeriod> periodMap, List<WorkPeriod> notFreePeriodList,
    		List<PhqInstitution> institutionList) 
    {
    	Map<String, PhqInstitution> institutionMap = new HashMap<String, PhqInstitution>();
    	List<PhqPractioner> practionerList = new ArrayList<PhqPractioner>();
    	File csvFile = new File(filePath);
    	if (!csvFile.exists() || !csvFile.isFile() || !csvFile.canRead()) {
    		throw new RuntimeException("Cannot read Practioner file: (" + filePath + ")");
    	}
    	
    	long practionerId = 0;
    	try {
        	BufferedReader csvFileReader = new BufferedReader(new FileReader(csvFile));
        	String line = null;
        	while ((line = csvFileReader.readLine()) != null) {
        		if (line.trim().equals("")) {
        			continue;
        		}
        		String[] practionerData = line.split(",");
        		if (practionerData.length != 17) {
        			log.error("Cannot read practioner date at line (length: {}), ({})", practionerData.length, line);
        			continue;
        		}
        		
        		//Skip title line
        		if (practionerData[0].trim().equalsIgnoreCase("Sno")) {
        			continue;
        		}
        		
        		// Sno,Practitioner Name,Practitioner Role,"Practitioner  Unavailability Mon","Practitioner Unavailability Tue",
        		// "Practitioner Unavailability Wed","Practitioner Unavailability Thur","Practitioner Unavailability Fri","Practitioner Unavailability Sat","Practitioner Unavailability Sun",
        		// "Practitioner  Language","Practitioner  Gender","Practitioner  Cost",Insitution Name,Insitution Type,
        		// Insitution Location,Location of insitutions,Day_insitutions,Hour_insitutions

        		String practionerName = practionerData[1].trim();
        		String practionerRole = practionerData[2].trim();
        		String language = practionerData[10].trim();
        		String gender = practionerData[11].trim();
        		String location = practionerData[15].trim();
        		int costPerHour = Integer.parseInt(practionerData[12].trim());
        		
        		PhqPractioner practioner = new PhqPractioner(practionerId, practionerName, gender, practionerRole, 
        				location, language, costPerHour);
        		practionerId++;
        		practionerList.add(practioner);
        		
        		List<WorkPeriod> currentNotFreePeriods = new ArrayList<WorkPeriod>();
        		for (int i = 0; i < 7; ++i) {
        			String notFreeTimeStr = practionerData[3 + i].trim();
        			WorkDay currentDay = dayList.get(i);
        			List<WorkTimeslot> currentSlotList = WorkTimeslot.readUnavailableTimeslotList(notFreeTimeStr);
        			if (currentSlotList != null && !currentSlotList.isEmpty()) {
        				for (WorkTimeslot slot : currentSlotList) {
        					String periodStr = currentDay.toString() + "-" + slot.toString();
        					WorkPeriod currentPeriod = periodMap.get(periodStr);
        					if (currentPeriod == null) {
        						log.error("Cannot read period in (Day: {}, Time: {})", currentDay, slot);
        					}
        					else {
        						//log.debug("ID: {}, Add unavailabe period in (Day: {}, Time: {})", practionerId, currentDay, slot);
                				currentNotFreePeriods.add(currentPeriod);
        						notFreePeriodList.add(currentPeriod);
        					}
        				}
        			}
        		}
       			
        		practioner.setNotFreePeriods(currentNotFreePeriods);
        		
        		String institutionName = practionerData[13].trim();
        		String institutionType = practionerData[14].trim();
        		String institutionLocation = practionerData[15].trim();
        		String institutionAddr = practionerData[16].trim();
        		PhqInstitution institution = institutionMap.get(institutionName.toLowerCase());
        		
        		if (institution == null) {
        			institution = new PhqInstitution(institutionList.size(), institutionName, 
        					institutionLocation, institutionType, institutionAddr);
        			institutionList.add(institution);
        			institutionMap.put(institutionName.toLowerCase(), institution);
        		}
        		
        		practioner.setInstitution(institution);
        	}
        	csvFileReader.close();
			
		} catch (Exception exp) {
			log.error("Read practioner data file (" + filePath + ") error", exp);
			throw new RuntimeException("Cannot read practioner file: (" + filePath + ")");
		}
    	
    	return practionerList;
    }
    
    public static PhqSessionScheduleSolution createUnsolvedSolution() {
    	long solutionId = 0;

    	List<WorkDay> dayList = WorkDay.getAllWorkDayList();
    	List<WorkTimeslot> timeslotList = WorkTimeslot.getAllTimeslotList();
    	List<WorkPeriod> allPeriodList = WorkPeriod.getAllPeriodList();
    	List<WorkPeriod> notFreePeriodList = new ArrayList<WorkPeriod>();
    	Map<String, WorkPeriod> periodMap = WorkPeriod.constructPeriodMap();
    	
    	List<PhqPatient> patientList = readPatientDataFromCSV("testdata\\patientData_v1.csv", dayList);
//    	for (PhqPatient patient : patientList) {
//    		log.info("Patient: {}", patient.getDesc());
//    	}

    	List<PhqInstitution> institutionList = new LinkedList<PhqInstitution>();
    	
    	List<PhqPractioner> practionerList = readPractionerDataFromCSV("testdata\\practionerData_v1.csv", 
    			dayList, timeslotList, periodMap, notFreePeriodList, institutionList);
    	practionerList.add(PhqPractioner.NIL_PRACTIONER);
    	
//    	for (PhqPractioner practioner : practionerList) {
//    		log.info("practioner: {}", (practioner == null) ? "NULL" : practioner.getDesc());
//    	}
    	
    	
    	List<PhqProcess> processList = new ArrayList<PhqProcess>(patientList.size());
    	long processId = 0;
    	for (PhqPatient patient : patientList) {
    		PhqProcess process = new PhqProcess(processId, null, patient, allPeriodList.get(0));
        	processList.add(process);
        	processId++;
    	}
    	
    	HardSoftScore score = HardSoftScore.ZERO;
    	PhqSessionScheduleSolution solution = new PhqSessionScheduleSolution(solutionId, practionerList, institutionList,
    			patientList, allPeriodList, processList, notFreePeriodList, score);
    	
    	return solution;
    }

	public static PhqSessionScheduleSolution startMatching(List<PatientDto> patientDtoList, List<PractitionerDto> practitionerDtoList) {
		PhqSessionScheduleSolution unsolvedSolution = createUnsolvedSolution(patientDtoList, practitionerDtoList);
		long startTime = System.currentTimeMillis();
		PhqSessionScheduleSolution solvedSolution = getSolver().solve(unsolvedSolution);
		long endTime = System.currentTimeMillis();

		log.info("\nSolved Solution in {} with score {}:\n",
				getTimePeriodDesc(endTime - startTime),
				solvedSolution.getScore());

		displayResult(solvedSolution);

		return solvedSolution;
	}

	public static PhqSessionScheduleSolution createUnsolvedSolution(List<PatientDto> patientDtoList, List<PractitionerDto> practitionerDtoList) {
		long solutionId = 0;

		List<PhqPatient> phqPatientList = convertPatientDtoList(patientDtoList);

		List<PhqInstitution> institutionList = new LinkedList<>();
		List<WorkPeriod> notFreePeriodList = new ArrayList<WorkPeriod>();

		List<PhqPractioner> practionerList = convertPractitionerDtoList(practitionerDtoList, institutionList, notFreePeriodList);
		practionerList.add(PhqPractioner.NIL_PRACTIONER);


		List<WorkPeriod> periodList = WorkPeriod.getAllPeriodList();

		List<PhqProcess> processList = new ArrayList<>();
		long processId = 0;
		for (PhqPatient patient : phqPatientList) {
			PhqProcess process = new PhqProcess(processId, null, patient, periodList.get(0));
			processList.add(process);
			processId++;
		}

		HardSoftScore score = HardSoftScore.ZERO;
		PhqSessionScheduleSolution solution = new PhqSessionScheduleSolution(solutionId, practionerList, institutionList,
				phqPatientList, periodList, processList, notFreePeriodList, score);

		return solution;
	}

	public static List<PhqPatient> convertPatientDtoList(List<PatientDto> patientDtoList) {
		List<PhqPatient> result = new ArrayList<>();

		List<WorkDay> workDayList = WorkDay.getAllWorkDayList();
		for(PatientDto dto : patientDtoList) {

			long patientId = 0;
			PhqPatient phqPatient = new PhqPatient(patientId, String.valueOf(dto.getSno()), dto.getPhq9Score(), dto.getPractitionerGender(),
					dto.getPractitionerLanguage(), dto.getInstitutionLocation(),
					WorkDay.getWorkDay(dto.getSessionDay().trim().substring(0, 2), workDayList)
			);

			result.add(phqPatient);
		}
		return result;
	}

	public static List<PhqPractioner> convertPractitionerDtoList(
			List<PractitionerDto> practitionerDtoList,
			List<PhqInstitution> institutionList,
			List<WorkPeriod> notFreePeriodList) {

		List<PhqPractioner> result = new ArrayList<>();

		List<WorkDay> workDayList = WorkDay.getAllWorkDayList();
		List<WorkDay> dayList = WorkDay.getAllWorkDayList();
		List<WorkTimeslot> timeslotList = WorkTimeslot.getAllTimeslotList();
		List<WorkPeriod> allPeriodList = WorkPeriod.getAllPeriodList();
		Map<String, WorkPeriod> periodMap = WorkPeriod.constructPeriodMap();
		Map<String, PhqInstitution> map = new HashMap<>();
		long practitionerId = 0;

		for(PractitionerDto dto : practitionerDtoList) {
			PhqPractioner practioner = new PhqPractioner(practitionerId, dto.getName(), dto.getGender(), dto.getRole(),
					dto.getInstitutionOverallLocation(), dto.getLanguage(), Integer.parseInt(dto.getCost()) );
			practitionerId++;

			String institutionName = dto.getInstitutionName();
			if( map.get(institutionName.toLowerCase()) == null ) {
				PhqInstitution institution = new PhqInstitution(institutionList.size(), dto.getInstitutionName(),
						dto.getInstitutionOverallLocation(), dto.getInstitutionType(), dto.getInstitutionDetailLocation());

				practioner.setInstitution(institution);
				institutionList.add(institution);
			} else {
				practioner.setInstitution(map.get(institutionName.toLowerCase()));
			}

			List<WorkPeriod> currentNotFreePeriods = new ArrayList<WorkPeriod>();
			for (int i = 0; i < 7; ++i) {
				String notFreeTimeStr = "";
				switch (i) {
					case 0: notFreeTimeStr = dto.getMonday(); break;
					case 1: notFreeTimeStr = dto.getTuesday(); break;
					case 2: notFreeTimeStr = dto.getWednesday(); break;
					case 3: notFreeTimeStr = dto.getTuesday(); break;
					case 4: notFreeTimeStr = dto.getFriday(); break;
					case 5: notFreeTimeStr = dto.getSaturday(); break;
					case 6: notFreeTimeStr = dto.getSunday(); break;
				}

				WorkDay currentDay = workDayList.get(i);
				List<WorkTimeslot> currentSlotList = WorkTimeslot.readUnavailableTimeslotList(notFreeTimeStr);
				if (currentSlotList != null && !currentSlotList.isEmpty()) {
					for (WorkTimeslot slot : currentSlotList) {
						String periodStr = currentDay.toString() + "-" + slot.toString();
						WorkPeriod currentPeriod = periodMap.get(periodStr);
						if (currentPeriod == null) {
							log.error("Cannot read period in (Day: {}, Time: {})", currentDay, slot);
						}
						else {
							//log.debug("ID: {}, Add unavailabe period in (Day: {}, Time: {})", practionerId, currentDay, slot);
							currentNotFreePeriods.add(currentPeriod);
							notFreePeriodList.add(currentPeriod);
						}
					}
				}
			}

			practioner.setNotFreePeriods(currentNotFreePeriods);
			result.add(practioner);
		}
		return result;
	}
}
