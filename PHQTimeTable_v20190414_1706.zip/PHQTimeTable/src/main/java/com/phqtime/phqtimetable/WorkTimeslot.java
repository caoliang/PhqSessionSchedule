package com.phqtime.phqtimetable;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WorkTimeslot")
public class WorkTimeslot implements Serializable {

	private static final Logger log = LoggerFactory.getLogger(WorkTimeslot.class);
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String[] TIMES = {"08:00 - 10:00", "10:00 - 12:00", "13:00 - 15:00", "15:00 - 17:00"};
	private static final List<Date> TIME_RANGES = defineTimeslotRange(TIMES);
	private static final List<WorkTimeslot> TIMESLOT_LIST = defineTimeslotList(TIMES);

	private long id;
	private int timeslotIndex;

    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getTimeslotIndex() {
        return timeslotIndex;
    }

    public void setTimeslotIndex(int timeslotIndex) {
        this.timeslotIndex = timeslotIndex;
    }

    public String getDesc() {
        String time = TIMES[timeslotIndex % TIMES.length];
        if (timeslotIndex > TIMES.length) {
            return "Timeslot " + timeslotIndex;
        }
        return time;
    }

    public static int getTimeslotSize() {
    	return TIMES.length;
    }
    
    @Override
    public String toString() {
        return Integer.toString(timeslotIndex);
    }

    public WorkTimeslot(long id, int timeslotIndex) {
    	this.id = id;
    	this.timeslotIndex = timeslotIndex;
    }
    
    public static List<WorkTimeslot> getAllTimeslotList() {
    	return TIMESLOT_LIST;
    }
    
    public static List<WorkTimeslot> readUnavailableTimeslotList(String unavailabeTimeslotList) {
    	if (unavailabeTimeslotList == null || unavailabeTimeslotList.trim().equals("")) {
    		return null;
    	}
    	
    	String[] slotStrList = unavailabeTimeslotList.trim().split("\\s");
    	List<WorkTimeslot> slotList = new ArrayList<WorkTimeslot>();
    	for (String slotStr : slotStrList) {
    		List<WorkTimeslot> notFreeList = readUnavailableTimeslot(slotStr);
    		if (notFreeList != null && !notFreeList.isEmpty()) {
	    		for (WorkTimeslot notFreeSlot : notFreeList) {
	    			if (notFreeSlot != null && !slotList.contains(notFreeSlot)) {
	        			slotList.add(notFreeSlot);
	        		}
	    		}
    		}
    	}
    	
    	return slotList;
    }
    
    public static List<WorkTimeslot> readUnavailableTimeslot(String unavailableTimeslot) {
    	if (unavailableTimeslot == null || unavailableTimeslot.trim().equals("")) {
    		return null;
    	}
    	
    	String[] checkTimeslot = unavailableTimeslot.trim().split("-");
    	if (checkTimeslot.length != 2) {
    		log.error("Cannot parse timeslot ({}) in length: {}", unavailableTimeslot, checkTimeslot.length);
    		return null;
    	}
    	
    	Date startTime = readTime(checkTimeslot[0]);
    	Date endTime = readTime(checkTimeslot[1]);
    	if (startTime == null || endTime == null) {
    		log.error("Cannot parse timeslot ({})", unavailableTimeslot);
    		return null;
    	}
    	
    	List<WorkTimeslot> slotList = new ArrayList<WorkTimeslot>();
    	
    	int rangeIndex = -1;
    	for (int i = 0; i < TIME_RANGES.size(); i += 2) {
    		Date startRange = TIME_RANGES.get(i);
    		Date endRange = TIME_RANGES.get(i + 1);
    		
    		// It is beyond current time range
    		if (startTime.after(endRange) || endTime.before(startRange)) {
    			continue;
    		}
    		
    		rangeIndex = i / 2;
    		WorkTimeslot currentSlot = TIMESLOT_LIST.get(rangeIndex);
    		slotList.add(currentSlot);
    	}
    	
    	return slotList;
    }
    
    private static Date readTime(String timeStr) {
    	DateFormat df = new SimpleDateFormat("HH:mm");
    	try {
			return df.parse(timeStr.trim());
		} catch (Exception exp) {
			log.error(String.format("Cannot parse time in HH:mm format ($1)", timeStr), exp);
		}
    	
    	return null;
    }
    
    // Define timeslot range
    private static List<Date> defineTimeslotRange(String[] definedTimes) {
    	List<Date> dateRange = new ArrayList<Date>();
    	for (String timeRange : definedTimes) {
    		String[] oneRange = timeRange.split("-");
    		Date startTime = readTime(oneRange[0]);
        	Date endTime = readTime(oneRange[1]);
        	dateRange.add(startTime);
        	dateRange.add(endTime);
    	}
    	
    	return dateRange;
    }
    
    private static List<WorkTimeslot> defineTimeslotList(String[] definedTimes) {
    	List<WorkTimeslot> timeslotList = new ArrayList<WorkTimeslot>(definedTimes.length);
    	for (int i = 0; i < definedTimes.length; ++i) {
    		WorkTimeslot timeslot = new WorkTimeslot(i, i);
     		timeslotList.add(timeslot);
    	}
    	
    	return timeslotList;
    }
}
