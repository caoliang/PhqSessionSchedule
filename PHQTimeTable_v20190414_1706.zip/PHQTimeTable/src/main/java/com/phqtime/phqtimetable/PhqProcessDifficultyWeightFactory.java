/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.phqtime.phqtimetable;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.optaplanner.core.impl.heuristic.selector.common.decorator.SelectionSorterWeightFactory;

public class PhqProcessDifficultyWeightFactory implements SelectionSorterWeightFactory<PhqSessionScheduleSolution, PhqProcess> {

    public PhqProcessDifficultyWeight createSorterWeight(PhqSessionScheduleSolution schedule, PhqProcess process) {
    	PhqPatient patient = process.getAssignedPatient();
    	int patientDifficultyCount = 0;
    	if (patient.getPreferLanguage() != patient.getPreferLanguageIndex("English")) {
    		patientDifficultyCount++;
    	}
    	if (patient.getPreferGender() != patient.getPreferGenderIndex("Any")) {
    		patientDifficultyCount++;
    	}
    	if (patient.getPreferLocation() != patient.getPreferLocationIndex("Any")) {
    		patientDifficultyCount++;
    	}
    	return new PhqProcessDifficultyWeight(process, patientDifficultyCount);
    }

    public static class PhqProcessDifficultyWeight implements Comparable<PhqProcessDifficultyWeight> {

        private final PhqProcess process;
        private final int processDifficultyCount;

        public PhqProcessDifficultyWeight(PhqProcess process, int processDifficultyCount) {
            this.process = process;
            this.processDifficultyCount = processDifficultyCount;
        }

        public int compareTo(PhqProcessDifficultyWeight other) {
           return new CompareToBuilder()
        		    // Processing patient with more conflict first
        		    .append(other.process.getAssignedPatient().getTotalConflicts(), process.getAssignedPatient().getTotalConflicts())
        		    // Processing difficult patient assignment first
        		    .append(other.processDifficultyCount, processDifficultyCount)
                    .append(process.getId(), other.process.getId())
                    .toComparison();
        }

    }

}
