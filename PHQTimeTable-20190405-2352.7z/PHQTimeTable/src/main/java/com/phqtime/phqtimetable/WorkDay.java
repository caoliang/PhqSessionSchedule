package com.phqtime.phqtimetable;

import java.io.Serializable;
import java.util.List;

public class WorkDay implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private static final String[] WEEKDAYS = {"Mo", "Tu", "We", "Th", "Fr"};

    
	private long id;

    private int dayIndex;

    private List<WorkPeriod> periodList;

    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getDayIndex() {
        return dayIndex;
    }

    public void setDayIndex(int dayIndex) {
        this.dayIndex = dayIndex;
    }

    public List<WorkPeriod> getPeriodList() {
        return periodList;
    }

    public void setPeriodList(List<WorkPeriod> periodList) {
        this.periodList = periodList;
    }

    public String getDesc() {
        String weekday = WEEKDAYS[dayIndex % WEEKDAYS.length];
        if (dayIndex > WEEKDAYS.length) {
            return "Day " + dayIndex;
        }
        return weekday;
    }

    public static int getWorkDaySize() {
    	return WEEKDAYS.length;
    }
    
    @Override
    public String toString() {
        return Integer.toString(dayIndex);
    }

    public WorkDay(long id, int dayIndex) {
    	this.id = id;
    	this.dayIndex = dayIndex;
    }
}
