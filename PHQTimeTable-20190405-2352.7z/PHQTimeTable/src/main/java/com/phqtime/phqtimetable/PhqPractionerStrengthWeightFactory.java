/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.phqtime.phqtimetable;

import java.util.List;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.optaplanner.core.impl.heuristic.selector.common.decorator.SelectionSorterWeightFactory;

public class PhqPractionerStrengthWeightFactory implements SelectionSorterWeightFactory<PhqSessionScheduleSolution, PhqPractioner> {

    public PhqPractionerStrengthWeight createSorterWeight(PhqSessionScheduleSolution schedule, PhqPractioner practioner) {
    	List<UnavailableDay> unavailableDayList = schedule.getUnavailableDayList();
    	int practionerDifficultyCount = 0;
    	for (UnavailableDay notFreeDay : unavailableDayList) {
    		if (notFreeDay.getPractioner() == practioner) {
    			practionerDifficultyCount++;
    		}
    	}
    	
    	return new PhqPractionerStrengthWeight(practioner, practionerDifficultyCount);
    }

    public static class PhqPractionerStrengthWeight implements Comparable<PhqPractionerStrengthWeight> {

        private final PhqPractioner practioner;
        private final int practionerStrengthCount;

        public PhqPractionerStrengthWeight(PhqPractioner practioner, int practionerStrengthCount) {
            this.practioner = practioner;
            this.practionerStrengthCount = practionerStrengthCount;
        }

        public int compareTo(PhqPractionerStrengthWeight other) {
           return new CompareToBuilder()
        		    // Processing practioner with more conflicts first
        		    .append(other.practioner.getTotalConflicts(), practioner.getTotalConflicts())
        		    // Processing practioner with more leave first
                    .append(other.practionerStrengthCount, practionerStrengthCount)
                    .append(practioner.getId(), other.practioner.getId())
                    .toComparison();
        }

    }

}
