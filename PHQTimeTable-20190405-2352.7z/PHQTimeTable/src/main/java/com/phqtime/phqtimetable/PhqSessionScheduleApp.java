/*
 * Copyright 2012 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.phqtime.phqtimetable;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;
import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhqSessionScheduleApp {

    private static Logger log = LoggerFactory.getLogger(PhqSessionScheduleApp.class);
	
    public static void main(String[] args) {
        // Build the Solver
        SolverFactory<PhqSessionScheduleSolution> solverFactory = SolverFactory.createFromXmlResource(
                "com/phqtime/phqtimetable/TimeSolver.solver.xml");
        Solver<PhqSessionScheduleSolution> solver = solverFactory.buildSolver();

        // Create sample test data
        PhqSessionScheduleSolution unsolvedSolution = createUnsolvedSolution();

        // Solve the problem
        PhqSessionScheduleSolution solvedSolution = solver.solve(unsolvedSolution);

        // Display the result
        log.info("\nSolved Solution:\n {}", displayResult(solvedSolution));
    }

    public static String displayResult(PhqSessionScheduleSolution solution) {
        StringBuilder buf = new StringBuilder();
        buf.append("Total score: ").append(solution.getScore().toString()).append("\n");
        
        List<PhqProcess> processList = solution.getPhqProcessList();
        long processIndex = 0;
        for (PhqProcess process : processList) {
            buf.append(processIndex).append(" -> ").append(process.getDesc()).append("\n");
            processIndex++;
        }
        return buf.toString();
    }

    public static PhqSessionScheduleSolution createUnsolvedSolution() {
    	long solutionId = 0;

    	List<WorkDay> dayList = new ArrayList<WorkDay>(WorkDay.getWorkDaySize());
    	for (int i = 0; i < WorkDay.getWorkDaySize(); ++i) {
    		WorkDay day = new WorkDay(i, i);
    		dayList.add(day);
    	}
    	
    	List<WorkTimeslot> timeslotList = new ArrayList<WorkTimeslot>(WorkTimeslot.getTimeslotSize());
    	for (int i = 0; i < WorkTimeslot.getTimeslotSize(); ++i) {
    		WorkTimeslot timeslot = new WorkTimeslot(i, i);
     		timeslotList.add(timeslot);
    	}
    	
    	List<PhqPatient> patientList = new ArrayList<PhqPatient>();
    	PhqPatient patient1 = new PhqPatient(1, "u1", 17, "Male", "Malay", "North", dayList.get(4));
    	patientList.add(patient1);
    	
    	PhqPatient patient2 = new PhqPatient(2, "u2", 12, "Male", "Chinese", "North", dayList.get(3));
    	patientList.add(patient2);
    	
    	PhqPatient patient3 = new PhqPatient(3, "u3", 11, "Male", "Chinese", "West", null);
    	patientList.add(patient3);
    	    	
    	List<PhqPractioner> practionerList = new ArrayList<PhqPractioner>();
    	PhqPractioner practioner1 = new PhqPractioner(1, "Tan Ah Kow", "Male", "counsellor", "West", "Chinese", 100);
    	practionerList.add(practioner1);
    	
    	PhqPractioner practioner2 = new PhqPractioner(2, "John Swift", "Male", "psychiatrist", "East", "English", 80);
    	practionerList.add(practioner2);
    	
    	PhqPractioner practioner3 = new PhqPractioner(3, "Muhammad bin Salmat", "Male", "psychologist", "North", "Malay", 80);
    	practionerList.add(practioner3);
    	
    	
    	List<WorkPeriod> periodList = new ArrayList<WorkPeriod>(dayList.size() * timeslotList.size());
    	int periodId = 0;
    	for (int i = 0; i < dayList.size(); ++i) {
    		WorkDay day = dayList.get(i);
    		List<WorkPeriod> dayPeriodList = new ArrayList<WorkPeriod>(timeslotList.size());
    		day.setPeriodList(dayPeriodList);
    		
    		for (int j = 0; j < timeslotList.size(); ++j) {
    			WorkTimeslot timeslot = timeslotList.get(j);
    			WorkPeriod currentPeriod = new WorkPeriod(periodId, day, timeslot);
    			dayPeriodList.add(currentPeriod);
    			periodList.add(currentPeriod);
    			periodId++;
    		}
    	}
    	
    	List<UnavailableDay> nonFreeDayList = new LinkedList<UnavailableDay>();
    	UnavailableDay p1Day1 = new UnavailableDay(1, practioner1, dayList.get(0));
    	nonFreeDayList.add(p1Day1);
    	UnavailableDay p1Day2 = new UnavailableDay(2, practioner1, dayList.get(1));
    	nonFreeDayList.add(p1Day2);
    	UnavailableDay p2Day3 = new UnavailableDay(3, practioner2, dayList.get(2));
    	nonFreeDayList.add(p2Day3);
    	UnavailableDay p3Day1 = new UnavailableDay(4, practioner3, dayList.get(0));
    	nonFreeDayList.add(p3Day1);
    	UnavailableDay p3Day2 = new UnavailableDay(5, practioner3, dayList.get(1));
    	nonFreeDayList.add(p3Day2);
    	UnavailableDay p3Day3 = new UnavailableDay(6, practioner3, dayList.get(2));
    	nonFreeDayList.add(p3Day3);
    	
    	List<PhqProcess> processList = new ArrayList<PhqProcess>(patientList.size());
    	PhqProcess process1 = new PhqProcess(1, practioner1, patient1, periodList.get(0));
    	processList.add(process1);

    	PhqProcess process2 = new PhqProcess(2, practioner1, patient2, periodList.get(0));
    	processList.add(process2);
    	
    	PhqProcess process3 = new PhqProcess(3, practioner1, patient3, periodList.get(0));
    	processList.add(process3);
    	    	
    	HardSoftScore score = HardSoftScore.ZERO;
    	PhqSessionScheduleSolution solution = new PhqSessionScheduleSolution(solutionId, practionerList, patientList, periodList, processList, nonFreeDayList, score);
    	
    	return solution;
    }
}
