/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.phqtime.phqtimetable;

import java.util.List;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.optaplanner.core.impl.heuristic.selector.common.decorator.SelectionSorterWeightFactory;

public class WorkPeriodStrengthWeightFactory implements SelectionSorterWeightFactory<PhqSessionScheduleSolution, WorkPeriod> {

    public WorkPeriodStrengthWeight createSorterWeight(PhqSessionScheduleSolution schedule, WorkPeriod period) {
    	List<UnavailableDay> freeDayList = schedule.getUnavailableDayList();
    	int periodDifficultyCount = 0;
    	for (UnavailableDay freeDay : freeDayList) {
    		if (freeDay.getDay() == period.getDay()) {
    			periodDifficultyCount++;
    		}
    	}
    	
    	return new WorkPeriodStrengthWeight(period, periodDifficultyCount);
    }

    public static class WorkPeriodStrengthWeight implements Comparable<WorkPeriodStrengthWeight> {

        private final WorkPeriod period;
        private final int periodStrengthCount;

        public WorkPeriodStrengthWeight(WorkPeriod period, int periodStrengthCount) {
            this.period = period;
            this.periodStrengthCount = periodStrengthCount;
        }

        public int compareTo(WorkPeriodStrengthWeight other) {
           return new CompareToBuilder()
        		    // Processing less busy day first
        		    .append(periodStrengthCount, other.periodStrengthCount)
        		    // Assignment 
        		    .append(period.getId(), other.period.getId())
                    .toComparison();
        }

    }

}
